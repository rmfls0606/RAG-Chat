# 최종 의료 RAG 챗봇 (v2.1)

## 들어 있는 파일

| 파일 | 내용 |
|---|---|
| `08f_final_chatbot_v21.ipynb` | 최종 챗봇 노트북 (최신). 재검색 기능(B2)은 들어 있지만 꺼 둠(`RETRY_FIX = False`, 11/03 B안 결정) |
| `08f_final_chatbot_v21_run_1103am.ipynb` | 11/03 오전 Colab 실행본. 출력 포함, 재검색 없는 발표 기준과 같은 동작. 데모 질문 테스트 결과를 그대로 볼 수 있음 |
| `final_config.json` | 챗봇 설정 (생성 모델, 어댑터, 재정렬, 거절 기준 4.92, 재검색 꺼짐 — 켤 때 기준 6.0) |
| `chatbot_test.jsonl` | 오전 실행의 데모 질문 16개 자동 테스트 결과 |

## 구성

bge-base-en-v1.5 + FAISS (후보 100) → MiniLM 최고점 < 4.92면 거절 → bge-reranker-large + v2-m3 앙상블 상위 10 → Qwen3-8B + DPO LoRA

## 실행 방법

1. `08f_final_chatbot_v21.ipynb`를 Colab에서 연다 (A100 권장, L4도 가능)
2. 드라이브에 `MyDrive/rag_msmarco/health/` 폴더가 있어야 한다
   - `final/final_config.json`, `dpo/adapter/` (DPO LoRA, 약 175MB), 문단 DB·FAISS 인덱스
   - 어댑터는 GitHub 파일 크기 제한(100MB)을 넘어서 이 zip에 넣지 않았다. 필요하면 드라이브 공유로 받는다
3. 런타임 → 모두 실행 → 드라이브 연결 허용
4. 데모 질문 자동 테스트 후 Gradio 공유 링크가 출력된다
